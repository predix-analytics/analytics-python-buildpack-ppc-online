import pkg_resources
version = pkg_resources.require('predix')[0].version
