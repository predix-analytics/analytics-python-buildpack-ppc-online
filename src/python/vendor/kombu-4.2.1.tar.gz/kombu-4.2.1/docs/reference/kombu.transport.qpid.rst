===================================================
 Apache QPid Transport - ``kombu.transport.qpid``
===================================================

.. currentmodule:: kombu.transport.qpid

.. automodule:: kombu.transport.qpid

    .. contents::
        :local:

    Transport
    ---------

    .. autoclass:: Transport
        :members:
        :undoc-members:

    Connection
    ----------

    .. autoclass:: Connection
        :members:
        :undoc-members:

    Channel
    -------

    .. autoclass:: Channel
        :members:
        :undoc-members:

    Message
    -------

    .. autoclass:: Message
        :members:
        :undoc-members:

