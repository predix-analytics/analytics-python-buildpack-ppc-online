==========================================================
 Amazon AWS Connection - ``kombu.asynchronous.aws.connection``
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.asynchronous.aws.connection

.. automodule:: kombu.asynchronous.aws.connection
    :members:
    :undoc-members:
