==========================================================
 SQS Connection - ``kombu.asynchronous.aws.sqs.connection``
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.asynchronous.aws.sqs.connection

.. automodule:: kombu.asynchronous.aws.sqs.connection
    :members:
    :undoc-members:
