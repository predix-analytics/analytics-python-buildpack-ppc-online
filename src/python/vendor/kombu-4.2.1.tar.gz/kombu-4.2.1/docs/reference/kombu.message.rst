==========================================================
 Message Objects - ``kombu.message``
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.message

.. automodule:: kombu.message
    :members:
    :undoc-members:
