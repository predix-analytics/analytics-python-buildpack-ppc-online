==========================================================
 UUID Utilities - ``kombu.utils.uuid``
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.utils.uuid

.. automodule:: kombu.utils.uuid
    :members:
    :undoc-members:
