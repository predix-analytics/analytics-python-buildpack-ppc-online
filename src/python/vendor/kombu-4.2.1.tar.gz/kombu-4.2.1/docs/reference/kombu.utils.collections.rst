==========================================================
 Custom Collections - ``kombu.utils.collections``
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.utils.collections

.. automodule:: kombu.utils.collections
    :members:
    :undoc-members:
