=================================================
 Consumer Scheduling - ``kombu.utils.scheduling``
=================================================

.. contents::
    :local:
.. currentmodule:: kombu.utils.scheduling

.. automodule:: kombu.utils.scheduling
    :members:
    :undoc-members:
